SUPLA FOR H801 WiFi LED CONTROLLER

1MB Flash:
boot_v1.5.bin--------------------->0x00000
h801_user1.1024.new.2.bin--------->0x01000
esp_init_data_default.bin--------->0xFC000
SPI-MODE: DIO

CONFIG MODE: Close the jumper for min. 5 seconds.

Demo (YouTube):
https://youtu.be/UR4vKSUqHxw
